<?php /* Smarty version 2.6.18, created on 2012-06-14 09:49:54
         compiled from pagination.tpl.php */ ?>
<div class="tMacroActions">
	<div class="checkboxAction">		
			<a href="#" class="singleButton eraseButton" style="display:none;">
				<span class="sb_lb">&#160;</span>
				<img src="../images/spacer.gif" alt="" title="" />
				apagar
				<span class="sb_rb">&#160;</span>
			</a>
			<div class="spacer">&#160;</div>
		</div>
		<div class="pagination" id="pagination">
			<div class="spacer">&#160;</div>
		</div>
		<div class="spacer">&#160;</div>
	</div>
</div>