<div class="footer">
	<div class="systemInfo">
		<strong>ABCD 1.2 BETA TRANSITIONAL</strong>
		<span>2009  BIREME - Centro Latino Americano e do Caribe de Informa��o em Ci�ncias da Sa�de</span>
		<a href="http://www.bireme.br" target=_blank>http://www.bireme.br</a>
	</div>
	<div class="distributorLogo">
		<a href="http://www.bireme.br" target=_blank><span>ONLY FOR TESTING - NOT FOR DITRIBUTION</span></a>
	</div>
	<div class="spacer">&#160;</div>
</div>
