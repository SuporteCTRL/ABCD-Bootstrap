../../../cgi-bin/mx orbe fst=@orbe.fst uctab=isisuc actab=isisac fullinv=orbe -all now tell=100
